#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define NUM_INTS 500
#define MAX_INT 499

int main() {
    int nums[NUM_INTS];
    int i, j, new_num;

    // Seed the random number generator
    srand(time(NULL));

    // Generate unique random integers
    for (i = 0; i < NUM_INTS; i++) {
        // Generate a new random number
        new_num = rand() % (MAX_INT + 1);

        // Check if the new number is already in the array
        for (j = 0; j < i; j++) {
            if (nums[j] == new_num) {
                // Number is not unique, generate a new one
                i--;
                break;
            }
        }

        // Number is unique, add it to the array
        if (j == i) {
            nums[i] = new_num;
        }
    }

    // Print the generated numbers
    for (i = 0; i < NUM_INTS; i++) {
        printf("%d ", nums[i]);
    }

    return 0;
}