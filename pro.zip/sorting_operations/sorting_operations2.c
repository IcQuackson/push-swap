/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sorting_operations2.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: quackson <quackson@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/19 14:48:12 by pedgonca          #+#    #+#             */
/*   Updated: 2023/02/22 00:02:49 by quackson         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "sorting_operations.h"

#include "stdio.h"
#include "assert.h"

int	check_if_n_is_bigger_than_stack(int n, t_list *head)
{
	return (n > get_max(head)->content);
}

void	sort_less_than_100(t_list **head_a, t_list **head_b)
{
	int	min;
	int	max;
	int	hold_first;
	int	hold_second;
	int	chunk;

	max = get_max(*head_a)->content;
	min = get_min(*head_a)->content;
	//printf("min:%d max:%d\n", min, max);

	int hold_first_moves;
	int hold_second_moves;

	chunk = 1;
	while (chunk <= 5)
	{
		while (get_first_number_from_chunk(*head_a, min, max, chunk))
		{
			hold_first = get_first_number_from_chunk(*head_a, min, max, chunk)->content;
			hold_second = get_last_number_from_chunk(*head_a, min, max, chunk)->content;\
			//printf("h1:%d h2:%d\n", hold_first, hold_second);
			hold_first_moves = calculate_get_lst_to_top(*head_a, hold_first);
			hold_second_moves = calculate_get_lst_to_top(*head_a, hold_second);
			if (hold_first_moves < hold_second_moves)
			{
				//TODO CHECK IF EL TO BE PUSHED IS SMALLER OR
				//BIGGER THAN STACK B
				/* if (*head_b != NULL && hold_first > get_max(*head_b)->content)
				{
					get_lst_to_top(*head_b, get_min(*head_b)->content, rotate_b, reverse_rotate_b);
				} */
				//assert(*head_b != NULL);
				
				if (*head_b != NULL && hold_first > get_max(*head_b)->content)
				{
					get_lst_to_top(*head_b, get_max(*head_b)->content, rotate_b, reverse_rotate_b);
				}
				get_lst_to_top(*head_a, hold_first, rotate_a, reverse_rotate_a);
				push_b(head_a, head_b);
			}
			else
			{
				get_lst_to_top(*head_a, hold_second, rotate_a, reverse_rotate_a);
				push_b(head_a, head_b);
			}
		}
		printf("CHUNK= %d\n", chunk);
		print_stacks(*head_a, *head_b);
		chunk++;
	}
	while (*head_b)
	{
		max = get_max(*head_b)->content;
		get_lst_to_top(*head_b, max, rotate_b, reverse_rotate_b);
		push_a(head_b, head_a);
	}
}

t_list	*get_max(t_list *head)
{
	t_list	*max;

	if (!head)
		return (NULL);
	max = head;
	while (head)
	{
		if (head->content > max->content)
			max = head;
		head = head->next;
	}
	return (max);
}

t_list	*get_min(t_list *head)
{
	t_list	*min;

	if (!head)
		return (NULL);
	min = head;
	while (head)
	{
		if (head->content < min->content)
			min = head;
		head = head->next;
	}
	return (min);
}

int	check_if_n_in_chunk(int n, int min, int max, int chunk_number)
{
	int	chunk_size;
	int	remaining_elements;
	int	current_element;
	int	i;

	chunk_size = (max - min + 1) / 5;
	remaining_elements = (max - min + 1) % 5 + 1;
	current_element = min;
	i = 0;
	//printf("chunk-size=%d rem_elem=%d curr_ele=%d\n", chunk_size, remaining_elements, current_element);
	while (--remaining_elements && ++i != chunk_number)
	{
		current_element += (chunk_size + 1);
		//printf("chunk_number=%d\n", i);
	}
	//printf("chunk-size=%d rem_elem=%d curr_ele=%d chunk=%d\n", chunk_size, remaining_elements, current_element, i);
	if (remaining_elements)
		chunk_size++;
	while (chunk_size--)
	{
		if (n == current_element++)
			return (1);
	}
	return (0);
}

t_list	*get_first_number_from_chunk(t_list *head, int min, int max, int chunk)
{
	while (head)
	{
		if (check_if_n_in_chunk(head->content, min, max, chunk))
			return (head);
		head = head->next;
	}
	return (NULL);
}

t_list	*get_last_number_from_chunk(t_list *head, int min, int max, int chunk)
{
	t_list	*last;

	last = NULL;
	while (head)
	{
		if (check_if_n_in_chunk(head->content, min, max, chunk))
			last = head;
		head = head->next;
	}
	return (last);
}

void	divide_sequence(int min_val, int max_val)
{
	int sequence_length = max_val - min_val + 1;
	int chunk_size = sequence_length / 5;
	int remaining_elements = sequence_length % 5;
	int current_element = min_val;
	int chunk_length;

	for (int i = 1; i <= 5; i++)
	{
		chunk_length = chunk_size;
		if (remaining_elements > 0)
		{
			chunk_length++;
			remaining_elements--;
		}
		printf("Chunk %d: ", i);
		for (int j = 0; j < chunk_length; j++)
		{
			printf("%d ", current_element);
			current_element++;
		}
		printf("\n");
	}
}

// smallest = 10
// biggest 20
// diff = biggest - smallest = 10
// diff / 5 = 2
// chunk_size = 1
// 10-11 11 16-18 19-21