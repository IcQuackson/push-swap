/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sorting_operations.h                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: quackson <quackson@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/06 22:34:44 by quackson          #+#    #+#             */
/*   Updated: 2023/02/19 23:52:26 by quackson         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SORTING_OPERATIONS_H
# define SORTING_OPERATIONS_H

# include "../smart_operations/smart_operations.h"
# include "../lst_operations/lst_operations.h"
# include "../others.h"

typedef struct chunk
{
	int	current_element;
	int	*current_chunk;
}	t_chunk;

void	sort(t_list **head_a, t_list **head_b);
void	sort_2(t_list *head_a);
void	sort_3(t_list *head_a);
void	sort_4(t_list **head_a, t_list **head_b);
void	sort_5(t_list **head_a, t_list **head_b);
void	sort_less_than_100(t_list **head_a, t_list **head_b);
void	divide_sequence(int min_val, int max_val);
t_list	*get_max(t_list *head);
t_list	*get_min(t_list *head);
int		check_if_n_in_chunk(int n, int min, int max, int chunk_number);
t_list	*get_first_number_from_chunk(t_list *head, int min, int max, int chunk);
t_list	*get_last_number_from_chunk(t_list *head, int min, int max, int chunk);

#endif