/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: quackson <quackson@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/01 19:26:21 by pedgonca          #+#    #+#             */
/*   Updated: 2023/02/22 00:02:05 by quackson         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "stack_operations/stack_operations.h"
#include "lst_operations/lst_operations.h"
#include "smart_operations/smart_operations.h"
#include "sorting_operations/sorting_operations.h"
#include "others.h"

#include <stdio.h>

int	main(int argc, char **argv)
{
	t_list	*head_a;
	t_list	*head_b;
	int		i;

	if (argc > 1)
	{
		head_a = NULL;
		head_b = NULL;
		if (!check_arguments(argc, argv))
		{
			printf("Error\n");
			return (0);
		}
		i = 0;
		while (++i < argc)
		{
			if (!add_new_node(argv[i], &head_a))
			{
				printf("Failed\n");
				free_stack(head_a);
				return (0);
			}
		}
		sort(&head_a, &head_b);
		//print_stacks(head_a, head_b);
		//divide_sequence(0, 499);
		//divide_sequence(3, 87);
		//print_stacks(head_a, head_b);
		/* write(1, "---------------------------------------\n", 40);
		write(1, "Init a and b:\n", 14); */
		


		/* printf("\n");
		divide_sequence(1, 9);
		printf("\n"); */
		
		/* printf("%d\n", check_if_n_in_chunk(8, 1, 9, 4));

		int k = 1;
		while (k < 10)
		{
			printf("moves to top: %d\n", calculate_get_lst_to_top(head_a, k));
			k++;
		} */
		
		//sort_less_than_100(&head_a, &head_b);
		//print_stacks(head_a, head_b);
		
		//printf("%d\n", check_if_n_in_chunk(5, 1, 9, 1));
		//printf("%d\n", check_if_n_in_chunk(1, 1, 9, 2));
		/* for (int i = 1; i < 6; i++)
		{
			printf("chunk = %d\n", i);
			for (int j = 1; j < 10; j++)
			{
				if (check_if_n_in_chunk(j, 1, 9, i))
					printf("%d \n", j);
			}
		} */
		/* for (int i = 1; i <= 5; i++)
		{
			t_list *node = get_first_number_from_chunk(head_a, 1, 9, i);
			if (node)
				printf("%d\n", node->content);
			else
				printf("-1\n");
		} */
		//printf("%d\n", is_number_in_chunk(7, 1, 9, 3));
		//printf("%d\n", is_number_in_chunk(4, 1, 9, 5));
	}
}

