/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   smart_operations2.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pedgonca <pedgonca@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/06 23:41:58 by quackson          #+#    #+#             */
/*   Updated: 2023/02/19 19:01:56 by pedgonca         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "smart_operations.h"

int	calculate_get_lst_to_top(t_list *head, int value)
{
	int		i;
	int		size;

	size = ft_lstsize(head);
	if (size <= 0)
		return (-1);
	i = 0;
	if (!get_node_by_value(head, value, &i))
		return (-1);
	if (i <= size / 2)
		return (i);
	else
		return (size - i);
}
