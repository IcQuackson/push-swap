/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   others.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pedgonca <pedgonca@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/07 13:17:10 by pedgonca          #+#    #+#             */
/*   Updated: 2023/02/19 20:49:36 by pedgonca         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef OTHERS_H
# define OTHERS_H

# include "lst_operations/lst_operations.h"
# include "unistd.h"

/* List aux functions */
int		ft_isdigit(int c);
long	ft_atol(const char *nptr);
t_list	**add_new_node(int n, t_list **stack_a_head);
void	free_stack(t_list *head);
void	print_stacks(t_list *head_a, t_list *head_b);
void	ft_putchar(char c);
void	ft_putnbr(int nb);
size_t	ft_strlen(const char *str);

/* argv checkers */
int		*check_arguments(char *str, int *size);
int		*check_if_duplicate(int n, int *values);
int		check_if_zero(char *nptr);
char	**ft_split(char const *s, char c);

#endif