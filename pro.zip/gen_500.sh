#!/bin/bash

numbers=($(seq 0 499 | shuf -n 500))
args=$(printf "%s " "${numbers[@]}")
ARG="$args" ./push_swap $ARG