/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   argv_checkers.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pedgonca <pedgonca@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/02 13:40:17 by pedgonca          #+#    #+#             */
/*   Updated: 2023/02/19 20:48:41 by pedgonca         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "others.h"
#include <limits.h>

#include <stdio.h>

int	*check_arguments(char *str, int *siz)
{
	int		i;
	int		size;
	int		*values;
	long	content;
	char	**args;
	char	**p;

	args = ft_split(str, ' ');
	if (!args)
		return (0);
	size = 0;
	p = args;
	while (*p++)
		size++;
	if (size == 0)
	{
		free(args);
		return (0);
	}
	*siz = size;
	values = malloc(size * sizeof(int));
	if (!values)
		return (0);
	i = 0;
	while (i < size)
	{
		content = ft_atol((const char *) args[i]);
		if (content == LONG_MAX || content > INT_MAX || content < INT_MIN)
		{
			write(2, "Error\n", 6);
			//printf("errrrooooo: %ld\n", content);
			return (0);
		}
		values[i] = (int) content;
		i++;
	}
	while (*args)
		free(*args++);
	free(args);
	return (check_if_duplicate(size, values));
}

int	*check_if_duplicate(int n, int *values)
{
	int	i;
	int	j;

	i = 0;
	j = 0;
	while (i < n)
	{
		j = i + 1;
		while (j < n)
		{
			if (values[i] == values[j])
			{
				free(values);
				return (NULL);
			}
			j++;
		}
		i++;
	}
	return (values);
}

static int	count_words(const char *str, char c)
{
	int	i;
	int	trigger;

	i = 0;
	trigger = 0;
	while (*str)
	{
		if (*str != c && trigger == 0)
		{
			trigger = 1;
			i++;
		}
		else if (*str == c)
			trigger = 0;
		str++;
	}
	return (i);
}

static char	*word_dup(const char *str, int start, int finish)
{
	char	*word;
	int		i;

	i = 0;
	word = malloc((finish - start + 1) * sizeof(char));
	while (start < finish)
		word[i++] = str[start++];
	word[i] = '\0';
	return (word);
}

char	**ft_split(char const *s, char c)
{
	size_t	i;
	size_t	j;
	int		index;
	char	**split;

	split = malloc((count_words(s, c) + 1) * sizeof(char *));
	if (!s || !(split))
		return (0);
	i = 0;
	j = 0;
	index = -1;
	while (i <= ft_strlen((const char *) s))
	{
		if (s[i] != c && index < 0)
			index = i;
		else if ((s[i] == c || i == ft_strlen(s)) && index >= 0)
		{
			split[j++] = word_dup(s, index, i);
			index = -1;
		}
		i++;
	}
	split[j] = 0;
	return (split);
}
